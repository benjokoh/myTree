const body = document.body;

body.addEventListener('click', () => {
  body.innerHTML = '<h1>Hello, world!</h1>';														 
});